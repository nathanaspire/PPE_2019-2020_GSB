<?php
	$initial = connecterServeurBD();
    $req = "select id, nom, prenom, login, mdp from Profil where login='".$unLogin."' and mdp='" . $unMdp . "'";
    $idJeuRes = mysqli_query( $initial,$req);
    if ( $idJeuRes ) {
        $ligne = mysqli_fetch_assoc($idJeuRes);
        json_encode($ligne);
        mysqli_free_result($idJeuRes);
    };

}
?>