<?php
/** 
 * Script de contrôle et d'affichage du cas d'utilisation "Saisir fiche de frais"
 * @package default
 * @todo  RAS
 */
  $repInclude = './include/';
  require($repInclude . "_init.inc.php");
  require($repInclude . "_EstPasVisiteur.php");

  // page inaccessible si visiteur non connecté
  if (!estVisiteurConnecte()) {
      header("Location: cSeConnecter.php");  
  }
  require($repInclude . "_entete.inc.html");
  require($repInclude . "_sommaire.inc.php");                             
?>
  <!-- Division principale -->
  <div id="contenu">
      <h2>Saisie des Comptes-Rendus</h2>
<?php

  if(isset($_POST["submit"])){

    $num = $_POST["numRap"];
    $date = $_POST["dateRap"];
    $visit = $_POST["listeVisiteur"];
    $pract = $_POST["listePracticien"];
    $motif = $_POST["listeMotif"];
    $bilan = $_POST["bilanRap"];
    $quantite1 = $_POST["qte1"];
    $quantite2 = $_POST["qte2"];
    
    $ajoutCoRendu = ajoutCompteRendu($num,$date,$bilan,$visit,$pract,$motif);

      if($_POST["qte1"] != null){
        $echant1 = $_POST["ech1"];
        $ajoutEchant1 =ajoutEchantillon($num,$echant1,$quantite1);
      };
      if($_POST["qte2"] != null){
        $echant2 = $_POST["ech2"];
        $ajoutEchant2 =ajoutEchantillon($num,$echant2,$quantite2);
      };
      

    
    
    
?>
    <p class="info">Compte-Rendu Sauvegardé ! </p> 
<?php
    }else{
  ?>

          
  <form action="/sophiagsb/cSaisieCompteRendu.php" method="post">
      <div class="corpsForm">
          <input type="hidden" name="etape" value="validerSaisie" />
          <fieldset>
            <legend>Mon Compte rendu</legend> 
            <!-- Numéro automatique de Compte-Rendu--> 
            
              <label>Rapport n°</label>
              <input type="text" name="numRap" readonly 
              value=<?php 
                  $numRapport = numRapMini();
                  echo $numRapport;
                ?> size="4"> 
              </input>
            </p>

            <!-- Date de rédaction -->
            <p>
              <label for="">Date: </label>
              <input type="date" name="dateRap"
                    title="Date du rapport" 
                    value="" />
            </p>

            <!-- Liste déroulante Visiteurs-->
            <p>
              <label>Auteur: </label>
              <?php
                  $unAuteur = obtenirDetailVisiteur($idConnexion, $idUser);
              ?>
              <option value="<?php echo $unAuteur["id"];?>">
                  <?php 
                  echo $unAuteur["nom"].' '.$unAuteur["prenom"];
                  ?> 
              </option>
            </p>

            <!-- Liste déroulante Practicien -->
            <p>
              <label>Practicien: </label>
              <select name="listePracticien">
                <optgroup label="Practicien">
                  <option disabled selected>Selection du Practicien</option>
                <?php
                  $pract = obtenirListePracticien();
                  while($tableauCtpeRendu = mysqli_fetch_assoc($pract)){
                ?>
                <option value="<?php echo $tableauCtpeRendu["idPract"];?>">
                  <?php echo $tableauCtpeRendu["nomPract"].' '.$tableauCtpeRendu["prenomPract"]; ?> 
                    
                </option>
                <?php 
                  }
                ?>
                <option value="autre"> Autre </option>
<!-- !!!!!!!!!!!!!!!!!!!!!!!!!!!! -->
                <!-- Mettre un if autre is selected -->
              </select>
            </p>

            <!-- Motif de la visite -->
            <p>
              <label>Motif: </label>
              <select name="listeMotif">
                <optgroup label="Motif">
                  <option disabled selected>Selection du Motif</option>
                <?php
                  $motif = obtenirListeMotif();
                  while($tableauCtpeRendu = mysqli_fetch_assoc($motif)){
                ?>
                <option value="<?php echo $tableauCtpeRendu["idMotif"];?>">
                  <?php echo $tableauCtpeRendu["libelle"]; ?> 
                </option>
                <?php 
                  }
                ?>
                <option id="autreMotif"> Autre </option>
<!--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-->
                <!-- Mettre un if autre is selected -->
              </select>
            </p>
            <?php
              include("/_init.inc.php");
            ?>

            <!-- Bilan de la visite -->
            <p>
              <label>Bilan: </label>
              <textarea size:"5" name="bilanRap"
                    maxlength="140"
                    title="Bilan de visite"></textarea>
            </p>

            <!-- Choix "pas d'echantillons -->
            <div>
              <input type="checkbox" id="noEchant" value="off" onclick="hideEchant();">
              <label >pas d'echantillons</label>
            </div>

            <!-- Echantillon 1  -->
            <fieldset id="lesEchant" class="formEchant">
              <p>
  			         Echantillon 1 :
                <select name="ech1">
                  <optgroup label="Medicaments">
                    <option disabled selected>Selection de l'echantillon</option>
                  <?php
                    $ech1 = obtenirListeEchant();
                    while($tableauCtpeRendu = mysqli_fetch_assoc($ech1)){
                  ?>
                  <option value="<?php echo $tableauCtpeRendu["mediCode"];?>">
                    <?php echo $tableauCtpeRendu["libelleCom"]; ?> 
                  </option>
                  <?php 
                    }
                  ?>
                </select>
               </p>

               <p>
                <!-- quantité Echantillon 1  -->
                quantité Ech 1:
                <input type= "number" name="qte1" min="0" max="99"step="1"> </input>
              </p>

              <!-- Echantillon 2 -->
              <!-- Ajouter qu'on ne peut pas choisir
              un echant selectionné dans le 1 ?  -->
              <p>
                Echantillon 2 :
                <select name="ech2">
                  <optgroup label="Medicaments">
                    <option disabled selected>Selection de l'echantillon</option>
                    <?php
                      $ech2 = obtenirListeEchant();
                      while($tableauCtpeRendu = mysqli_fetch_assoc($ech2)){
                    ?>
                    <option value="<?php echo $tableauCtpeRendu["mediCode"];?>">
                      <?php echo $tableauCtpeRendu["libelleCom"]; ?> 
                    </option>
                    <?php 
                      }
                    ?>
                  </optgroup>
                </select>
              </p>

              <p>
                <!-- quantité Echantillon 2  -->
                 quantité Ech 2:
                <input type= "number" name="qte2" min="0" max="99"step="1"> </input>
              </p>

            </fieldset>
          </fieldset>
      </div>
      <div class="piedForm">
      <p>
        <input name="submit" type="submit" value="Valider" size="20" 
               title="Enregistrer le compte-rendu" />
        <input id="annuler" type="reset" value="Effacer" size="20" />
      </p> 
    </div>
 <?php 
    };
  ?>       
  </form>

  </div>
<?php        
  require($repInclude . "_pied.inc.html");
  require($repInclude . "_fin.inc.php");
?>
<script type="text/javascript">
  
  function hideEchant(){
    var checkbox = document.getElementById("noEchant");
    var echant = document.getElementById("lesEchant");
    if(checkbox.checked == true){
      //alert("toto");
      echant.style.display = "none";
      checkbox.value("on");

    } else {
      echant.style.display = "block";
      checkbox.value("off");
    };
  };

</script> 
