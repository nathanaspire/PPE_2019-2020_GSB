<?php
/** 
 * Script de contrôle et d'affichage du cas d'utilisation "Consulter une fiche de frais"
 * @package default
 * @todo  RAS
 */
  $repInclude = './include/';
  require($repInclude . "_init.inc.php");
  require($repInclude . "_EstPasVisiteur.php");

  // page inaccessible si visiteur non connecté
  if ( ! estVisiteurConnecte() ) {
      header("Location: cSeConnecter.php");  
  }
  require($repInclude . "_entete.inc.html");
  require($repInclude . "_sommaire.inc.php");
  
  // acquisition des données entrées, ici le numéro de mois et l'étape du traitement
  $moisSaisi=lireDonneePost("lstMois", "");
  $etape=lireDonneePost("etape",""); 

  if ($etape != "demanderConsult" && $etape != "validerConsult") {
      // si autre valeur, on considère que c'est le début du traitement
      $etape = "demanderConsult";        
  }                                 
?>
  <!-- Division principale -->
  <div id="contenu">
      <h2>Mes comptes-rendus</h2>

      <h3>Mois à sélectionner : </h3>
      <form action="" method="post">
      <div class="corpsForm">
          <input type="hidden" name="etape" value="validerConsult" />
      <p>
        <label for="lstMois">Mois : </label>
        <select id="lstMois" name="lstMois" title="Sélectionnez le mois souhaité pour les comptes-rendus">
            <?php
                // on propose tous les mois pour lesquels le visiteur a une fiche de frais
                $req = obtenirReqMoisFicheFrais(obtenirIdUserConnecte());
                $idJeuMois = mysqli_query($idConnexion,$req);
                $lgMois = mysqli_fetch_assoc($idJeuMois);
                while ( is_array($lgMois) ) {
                    $mois = $lgMois["mois"];
                    $noMois = intval(substr($mois, 4, 2));
                    $annee = intval(substr($mois, 0, 4));
            ?>    
            <option value="<?php echo $mois; ?>"<?php if ($moisSaisi == $mois) { ?> selected="selected"<?php } ?>><?php echo obtenirLibelleMois($noMois) . " " . $annee; ?></option>
            <?php
                    $lgMois = mysqli_fetch_assoc($idJeuMois);        
                }
            ?>
        </select>
      </p>
      </div>
      <div class="piedForm">
      <p>
        <input id="ok" type="submit" value="Valider" size="20"
               title="Demandez à consulter les comptes-rendus d'un mois" />
        <input id="annuler" type="reset" value="Effacer" size="20" />
      </p> 
      </div>
        
      </form>
<?php      

// demande et affichage des différents éléments (forfaitisés et non forfaitisés)
// de la fiche de frais demandée, uniquement si pas d'erreur détecté au contrôle
    if ( $etape == "validerConsult" ) {
        $cpteRendu= recupDonneesCompteRendu(obtenirIdUserConnecte(),$moisSaisi);
        // si elle n'existe pas : erreur
        if (mysqli_num_rows($cpteRendu) == 0) {
?>
        <div style="text-align: center">
          <h3>Il n'y a pas de comptes-rendus ici !</h3>

        <a href="cSaisieCompteRendu.php"><input type="button" value="Ajouter un Compte-rendu"></a>
        </div>
<?php
      } else {
?>
    <h3>Comptes-rendus de <?php echo obtenirLibelleMois(intval(substr($moisSaisi,4,2))); ?>
    	
    </h3>

    <?php
        
      
      while($tableauCpteRend = mysqli_fetch_assoc($cpteRendu)){

    ?>
    <div class="encadre">
  	<table class="listeLegere">
  	   <caption>Compte-rendu n°<?php echo $tableauCpteRend["numRap"] ?></caption>
        <tr>
            <!-- Titre des Elements du Compte rendu -->
                <th>Date</th>
                <th>Practicien</th>
                <th>Motif</th>
        </tr>
        <tr>
            <!-- Elements du Compte rendu -->
                <td><?php echo $tableauCpteRend["dateRap"]; ?></td>
                <td><?php echo $tableauCpteRend["nomPract"]; ?> 
                  <?php echo $tableauCpteRend["prenomPract"]; ?>
                </td>
                <td><?php echo $tableauCpteRend["libelle"]; ?></td>


        </tr>
    </table>

        <table class="listeLegere">
          <?php
            $cpteRenduEchant= recupDonnesCpteRenduEchant($tableauCpteRend["numRap"]);
            $i=1;
            while($tableauEchant = mysqli_fetch_assoc($cpteRenduEchant)){
            ?>
              <tr>
                
                <!-- Titre echantillons -->
                    <th>Echantillon <?php echo $i ?> </th>
                    <th>Quantite <?php echo $i ?> </th>

              </tr>
              <tr>
                <?php

                ?>
                <!-- Infos Echantillons -->
                    <td><?php echo $tableauEchant["libelleCom"]; ?></td>
                    <td><?php echo $tableauEchant["quantite"]; ?></td>


              </tr>
              <?php
              $i++;
                }
              ?>
        </table>

    <table class="listeLegere">
        <tr>
            <?php

            ?>
            <!-- Titre Bilan -->
                <th>Bilan</th>

        </tr>
        <tr>
            <?php

            ?>
            <!-- Elements du bilan -->
                <td><?php echo $tableauCpteRend["bilan"]; ?></td>


        </tr>
    </table>

  </div> <br> <br>
<?php
        }
      }
    };
?>    
  </div>
<?php        
  require($repInclude . "_pied.inc.html");
  require($repInclude . "_fin.inc.php");
?> 