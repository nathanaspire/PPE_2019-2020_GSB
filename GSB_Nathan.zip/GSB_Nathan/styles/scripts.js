var checkbox = document.getElementById("noEchant");
var echant = document.getElementById("lesEchant");
alert("titi");
if(checkbox.checked == true){
	alert("toto");
	echant.style.display == "none";
};
