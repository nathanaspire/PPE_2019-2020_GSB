<?php
$visit = role(); 

if ( $visit == true ) 
  {
        header("Location: cNoAccess.php");  
  }
?>