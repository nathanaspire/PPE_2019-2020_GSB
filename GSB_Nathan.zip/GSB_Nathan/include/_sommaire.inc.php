<?php
/** 
 * Contient la division pour le sommaire, sujet à des variations suivant la 
 * connexion ou non d'un utilisateur, et dans l'avenir, suivant le type de cet utilisateur 
 * @todo  RAS
 */

?>
    <!-- Division pour le sommaire -->
    <div id="menuGauche">
    <div id="infosUtil">
    <?php
    $visit = role();   
      if (estVisiteurConnecte() ) {
          $idUser = obtenirIdUserConnecte() ;
          $lgUser = obtenirDetailVisiteur($idConnexion, $idUser);
          $nom = $lgUser['nom'];
          $prenom = $lgUser['prenom'];            
    ?>
        <h2>
    <?php  
            echo $nom . " " . $prenom ;
            
    ?>
        </h2>
    <?php if($visit == true){?>
        <h3>Visiteur médical</h3>
    <?php }else{ ?>
        <h3>Comptable</h3>
    <?php } 
    }
    ?>     
    
       
      
      </div>  
<?php      
  if (estVisiteurConnecte() ) {
?>
        <ul id="menuList">
           <li class="smenu">
              <a href="cAccueil.php" title="Page d'accueil">Accueil</a>
           </li>
           <li class="smenu">
              <a href="cSeDeconnecter.php" title="Se déconnecter">Se déconnecter</a>
           </li>

           <?php
           /*Si c'est un visiteur*/
           if( $visit == true){
           ?>

           <li class="smenu">
              <a href="cSaisieFicheFrais.php" title="Saisie fiche de frais du mois courant">Saisie fiche de frais</a>
           </li>
           <li class="smenu">
              <a href="cConsultFichesFrais.php" title="Consultation de mes fiches de frais">Mes fiches de frais</a>
           </li>
           <li class="smenu">
                <a href="cSaisieCompteRendu.php" title="Saisie comptes-rendus">Saisir un Compte-rendu</a>
            </li>
            <li class="smenu">
              <a href="cMesCompteRendus.php" title="Mes comptes-rendus">Mes comptes-rendus</a>
            </li>
           <?php 
           /*Sinon c'est un comptable*/
            }else{
              
           ?>
             <li class="smenu">
                <a href="cValidationFichesFrais.php" title="Validation">Validation des fiches</a>
             </li>
             <li class="smenu">
                <a href="cSuivisOperations.php" title="operations">Suivis des opérations</a>
             </li>
       </ul>
       <?php };?>

        <?php
          // affichage des éventuelles erreurs déjà détectées
          if ( nbErreurs($tabErreurs) > 0 ) {
              echo toStringErreurs($tabErreurs) ;
          }
  }
        ?>
    </div>
    