<!-- SAISIE NOUVEAU MOTIF DE VISITE -->

<p id="newMotif"></p>
<form method="get" action="">
<input type="text" id="comment" value="Titre du Motif" />
<input type="button" id="send" value="Envoyer" onclick="sendMotif();" />
</form>

<?php
	$post_id = ! empty($_GET['post_id']);
	$name = ! empty($_GET['name']);
	$comment = ! empty($_GET['comment']);

	if ($post_id && $name && $comment)
	echo '(PHP) OK...';
	else
	echo '(PHP) Error...';
?>

<script type="text/javascript">
	function sendMotif()
	{
		// Récupération des valeurs des champs de formulaire
		var comment = document.getElementById('comment').value;

		// Préparation de la querystring d'URL
		var params = '&comment=' + encodeURIComponent(comment);

		// Récupération de l'objet XHR
		var xhr = getXhr();

		// On assigne une fonction qui, lorsque l'état de la requête change, va traiter le résultat
		xhr.onreadystatechange = function()
		{
		// readyState 4 = requête terminée
		if (xhr.readyState == 4)
		{
		// status 200 = page requêtée trouvée
		if (xhr.status == 200)
		ajaxBox_setText(xhr.responseText);
		// Page non trouvée
		else
		ajaxBox_setText('Error...');
		}
		};

		// Passage des paramètres à l'URL puis éxecution de la requête
		var url = '/cSaisieCompteRendu.php' + params;
		xhr.open('GET', url, true);
		xhr.send(null);
		}


		// Fonction de mise à jour du contenu de l'élement HTML #result
		function ajaxBox_setText(pText)
		{
		var p = document.getElementById('result');
		p.appendChild(document.createTextNode(pText));
	}
</script>