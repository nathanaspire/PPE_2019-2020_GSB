<?php
$visit = role(); 

if ( $visit == false ) 
  {
        header("Location: cNoAccess.php");  
  }
?>