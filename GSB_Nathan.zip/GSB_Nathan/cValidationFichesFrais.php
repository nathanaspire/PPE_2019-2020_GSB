<?php
/** 
 * Script de contrôle et d'affichage du cas d'utilisation "Consulter une fiche de frais"
 * @package default
 * @todo  RAS
 */
  $repInclude = './include/';
  require($repInclude . "_init.inc.php");
  require($repInclude . "_EstPasComptable.php");

  // page inaccessible si visiteur non connecté
  if ( ! estVisiteurConnecte() ) {
      header("Location: cSeConnecter.php");  
  }
  require($repInclude . "_entete.inc.html");
  require($repInclude . "_sommaire.inc.php");
  
  // acquisition des données entrées, ici le numéro de mois et l'étape du traitement
  $moisSaisi=lireDonneePost("lstMois", "");
  $etape=lireDonneePost("etape",""); 

  if ($etape != "demanderConsult" && $etape != "validerConsult") {
      // si autre valeur, on considère que c'est le début du traitement
      $etape = "demanderConsult";        
          
      }                                  
?>
  <!-- Division principale -->
  <div id="contenu">
      <h2>Mes fiches de frais</h2>
      <h3>Mois à sélectionner : </h3>


      <!-- Liste déroulante mois-->
      <form action="" method="post">
      <div class="corpsForm">
          <input type="hidden" name="etape" value="validerConsult" />

      <p>
        <label for="lstMois">Mois : </label>
        <!-- SELECT sert a créer une liste déroulante comoposée d'OPTIONS -->
        <select id="lstMois" name="lstMois" title="Sélectionnez le mois souhaité pour la fiche de frais">

            <?php
                // on propose tous les mois pour lesquels le visiteur a une fiche de frais
                $req = obtenirReqMoisFicheFrais(toutLesVisit());
                $idJeuMois = mysqli_query($idConnexion,$req);
                $lgMois = mysqli_fetch_assoc($idJeuMois);
                while ( is_array($lgMois) ) {
                    $mois = $lgMois["mois"];
                    $noMois = intval(substr($mois, 4, 2));
                    $annee = intval(substr($mois, 0, 4));
            ?>    
            <option value="<?php echo $mois; ?>"<?php if ($moisSaisi == $mois) { ?> selected="selected"<?php } ?>> <?php echo obtenirLibelleMois($noMois) . " " . $annee; ?></option>
            <?php
                    $lgMois = mysqli_fetch_assoc($idJeuMois);        
                }
                mysqli_free_result($idJeuMois);
            ?>
        </select>

      </p>
      </div>

      <!-- Validation -->
      <div class="piedForm">
      <p>
        <input id="ok" type="submit" value="Valider" size="20"
               title="Demandez à consulter les fiches de frais du mois selectionné" />
      </p> 
      </div>
      </form>
<?php      

// demande et affichage des différents éléments (forfaitisés et non forfaitisés)
// de la fiche de frais demandée, uniquement si pas d'erreur détecté au contrôle
    if ( $etape == "validerConsult" ) {
        if ( nbErreurs($tabErreurs) > 0 ) {
            echo toStringErreurs($tabErreurs) ;
        }
        else {
?>
    <h3>Fiches de frais du mois de <?php echo obtenirLibelleMois(intval(substr($moisSaisi,4,2))) . " " . substr($moisSaisi,0,4); ?> :
    <div class="encadre">

    <table class="listeLegere">
       <caption>Quantités des éléments forfaitisés</caption>
              <tr>
                <th class="date">Visiteur</th>
                <th class="libelle">Libellé</th>
                <th class="montant">Montant</th>
                <th class="date">Validation</th>            
              </tr>
        <?php 
            // demande de la requête pour obtenir la liste des éléments 
            // forfaitisés des visiteurs pour le mois demandé
            $fiche = obtenirReqEltsForfaitFicheFraisCompt($moisSaisi);
            //echo $fiche;
            $compte= mysqli_num_rows($fiche);
            $i=0;
            while($tableau = mysqli_fetch_assoc($fiche)){
        ?>
              <tr>
                <td><?php echo $tableau["idVisiteur"] ; ?></td>
                <td><?php echo filtrerChainePourNavig($tableau["idFraisForfait"]) ; ?></td>
                <td><?php echo $tableau["quantite"] ; ?></td>
              </tr>
        <?php
              $i++;
            }
        ?>

    </table>
    <table class="listeLegere">
       <caption>Descriptif des éléments hors forfait - <?php /* echo $tabFicheFrais["nbJustificatifs"]; */?> justificatifs reçus -
       </caption>
             <tr>
                <th class="Visiteur">Visiteur</th>
                <th class="libelle">Libellé</th>
                <th class="montant">Montant</th>
                <th class="date">Validation</th>                
             </tr>
      <?php          
            // demande de la requête pour obtenir la liste des éléments hors
            // forfait du visiteur connecté pour le mois demandé
            $req = obtenirReqEltsHorsForfaitFicheFraisCompt($moisSaisi);
            $compteHorsForfait = mysqli_num_rows($req);
            // parcours des éléments hors forfait 
            $j=0;
            while ( $horsForfait = mysqli_fetch_assoc($req)) {
            ?>
                <tr>
                   <td><?php echo $horsForfait["idVisiteur"] ; ?></td>
                   <td><?php echo filtrerChainePourNavig($horsForfait["libelle"]) ; ?></td>
                   <td><?php echo $horsForfait["montant"] ; ?></td>
                </tr>
            <?php
                $j++;
            }
      ?>
    </table>
  </div>
<?php
        }
    }
?> 
  </div>
<?php        
  require($repInclude . "_pied.inc.html");
  require($repInclude . "_fin.inc.php");
?> 
